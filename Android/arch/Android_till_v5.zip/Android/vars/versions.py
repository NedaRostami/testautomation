class Version:

    variables = {}

    def __init__(self):
        self.app_package = 'com.sheypoor.mobile.debug'
        self.variables.update(
            APP_PACKAGE=self.app_package,
            USER_SETTINGS='تنظیمات حساب کاربری',
            MYACCOUNT='آگهی‌های من',
            OfferID=self.app_package + ':id/offerName',
            SupportTEL='(021) 545-87',
            SERP_VALIDATOR='ثبت رایگان آگهی',
            Region_Header=self.app_package + ':id/region_header_title',
            Category_Header=self.app_package + ':id/categoryTitle',
            FILTER_COUNT=self.app_package + ':id/filter_count',
            FILTER_HEADER=self.app_package + ':id/filter_header',
            SAVE_SEARCH=self.app_package + ':id/icon_save_search',
            offer_status=self.app_package + ':id/offer_status',
            HOME_ACTIVITY='com.sheypoor.mobile.activities.MainActivity',
            SPLASH_ACTIVITY='com.sheypoor.mobile.mvp.ui.SplashScreenActivity',
            CONTACT_SUPPORT='تماس با پشتیبانی',
            APPROVED_MESSAGE='فعال',
            DELETED_MESSAGE='حذف شده',
            LOCATION_SPINNER='موقعیت مکانی',
            LOGIN_OR_REGISTER='ورود یا ثبت‌نام در شیپور',
            TRY_AGAIN='تلاش مجدد',
            SERP_LINK='همه آگهی‌ها',
            CHAT_LINK='لیست چت‌ها',
            EDIT_TEXT='android.widget.EditText',
            AUTOMATION_NAME='UiAutomator2',
            PLATFORM_NAME_ANDROID='Android',
            DEVICE_ORIENTATION='portrait',
            appiumVersion='1.9.1',
            EXPIRED='منقضی شده',
            REJECTED='رد شده',
            WAITING='در انتظار تایید',
            LOCATION_SPINNER_DEFAULT='موقعیت مکانی',
            FAV_LINK='آگهی‌های پسندیده',
            PAYMENT_BUTTON=self.app_package + ':id/postlistingPayButton',
            MY_LISTING_ITEM=self.app_package + ':id/item_offer_user_title',
            ITEM_STATUS=self.app_package + ':id/item_offer_user_status',
            DISCOUNT_CODE=self.app_package + ':id/postlistingCouponButton',
            APPLY_COUPON=self.app_package + ':id/couponCodeApplyTextView',
            DISCOUNT_AMOUNT=self.app_package + ':id/couponCodePriceTextView',
            PAYABLE_AMOUNT=self.app_package + ':id/couponCodeDiscountTextView',
            COUPON_CODE_SUBMIT=self.app_package + ':id/couponCodeSubmitTextView',
            ReturnAppText='android=UiScrollable(UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().text("بازگشت به برنامه"))',
            ReturnAppDesc='android=UiScrollable(UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().description("بازگشت به برنامه"))',
        )

    @staticmethod
    def not_found():
        raise Exception('Could not find requested version')


class V3_4_4(Version):

    def __init__(self):
        super().__init__()
        self.variables.update(
            USER_SETTINGS='آگهی‌های من'
        )


class V3_4_5(V3_4_4):

    def __init__(self):
        super().__init__()
        self.variables.update(
            MYACCOUNT='آگهی های من',
            SupportTEL='(021) 545-87'
        )


class V4_0_4(V3_4_5):

    def __init__(self):
        super().__init__()
        self.variables.update(
            APPROVED_MESSAGE='منتشر شده',
            CAT_ROOT=self.app_package + ':id/root',
            CONTACT_SUPPORT='پشتیبانی',
            FILTER_COUNT=self.app_package + ':id/filtersCount',
            FILTER_HEADER=self.app_package + ':id/filterButton',
            HOME_ACTIVITY='com.sheypoor.mobile.activities.HomeActivity',
            LOGIN_OR_REGISTER='ورود یا ثبت ‌نام در شیپور',
            OfferID=self.app_package + ':id/offerTitle',
            Region_Header=self.app_package + ':id/selectedLocationName',
            SAVE_SEARCH=self.app_package + ':id/saveSearchTitle',
            SAVE_SEARCH_ICON=self.app_package + ':id/saveSearchIcon',
            SERP_ACTIVITY='com.sheypoor.mobile.feature.home_serp.SerpActivity',
            SERP_VALIDATOR='وسایل نقلیه'
        )


class V4_0_5(V4_0_4):

    def __init__(self):
        super().__init__()


class V4_0_6(V4_0_5):

    def __init__(self):
        super().__init__()
        self.variables.update(
            DELETED_MESSAGE='غیرفعال',
            LOCATION_SPINNER='تهران, تهران',
            offer_status=self.app_package + ':id/item_offer_user_status'
        )


class V4_0_7(V4_0_6):

    def __init__(self):
        super().__init__()


class V4_0_8(V4_0_7):

    def __init__(self):
        super().__init__()


class V4_0_9(V4_0_8):

    def __init__(self):
        super().__init__()


class V4_0_10(V4_0_9):

    def __init__(self):
        super().__init__()


class V4_1_0(V4_0_10):

    def __init__(self):
        super().__init__()
        self.variables.update(
            APPROVED_MESSAGE= 'فعال',
            VitrinInSerpID=self.app_package + ':id/title',
        )


class V4_1_1(V4_1_0):

    def __init__(self):
        super().__init__()


class V4_1_2(V4_1_1):

    def __init__(self):
        super().__init__()


class V4_1_3(V4_1_2):

    def __init__(self):
        super().__init__()
        self.variables.update(
            APPROVED_MESSAGE='منتشر شده',
            DELETED_MESSAGE='حذف شده'
        )


class V4_1_4(V4_1_3):

    def __init__(self):
        super().__init__()


class V4_1_5(V4_1_4):

    def __init__(self):
        super().__init__()


class V4_1_6(V4_1_5):

    def __init__(self):
        super().__init__()


class V4_1_7(V4_1_6):

    def __init__(self):
        super().__init__()


class V4_1_8(V4_1_7):

    def __init__(self):
        super().__init__()


class V4_1_9(V4_1_8):

    def __init__(self):
        super().__init__()


class V4_2_0(V4_1_9):

    def __init__(self):
        super().__init__()


class V4_2_1(V4_2_0):

    def __init__(self):
        super().__init__()


class V4_3_0(V4_2_1):

    def __init__(self):
        super().__init__()


class V4_3_1(V4_3_0):

    def __init__(self):
        super().__init__()


class V4_3_2(V4_3_1):

    def __init__(self):
        super().__init__()


class V4_3_3(V4_3_2):

    def __init__(self):
        super().__init__()


class V4_4_0(V4_3_3):

    def __init__(self):
        super().__init__()
        self.variables.update(CAR_FILTER_LIST='لیست برند‌ها')


class V4_4_1(V4_4_0):

    def __init__(self):
        super().__init__()
        self.variables.update(CAR_FILTER_LIST='لیست برندها و مدل‌های خودرو')


class V4_4_2(V4_4_1):

    def __init__(self):
        super().__init__()
